﻿using Apache.NMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestMDEWinformSender
{
    public partial class Form1 : Form
    {
        public static Form1 Mainform;
        static List<string> Messages = new List<string>();
        public Form1()
        {
            InitializeComponent();
            Mainform = this;
            Thread t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            SendNewMessage(TextTextBox.Text, TopicTextBox.Text);
        }
        private static void SendNewMessage(string text,string topic)
        {
            string brokerUri = "activemq:tcp://localhost:61616";  // Default port
            NMSConnectionFactory factory = new NMSConnectionFactory(brokerUri);
            using (IConnection connection = factory.CreateConnection())
            {
                connection.Start();
                using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                using (IDestination dest = session.GetTopic(topic))
                using (IMessageProducer producer = session.CreateProducer(dest))
                {
                    producer.DeliveryMode = MsgDeliveryMode.NonPersistent;

                    producer.Send(session.CreateTextMessage(text));
                    Console.WriteLine("Sent {text} messages");
                }
            }
        }
        bool ReadNextMessage()
        {

            string brokerUri = "activemq:tcp://10.197.10.32:61616";  // Default port
            NMSConnectionFactory factory = new NMSConnectionFactory(brokerUri);
            try
            {
            using (IConnection connection = factory.CreateConnection())
            {
                
                    connection.Start();
                    using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                    using (IDestination dest = session.GetTopic(TopicTextBox.Text))
                    using (IMessageConsumer consumer = session.CreateConsumer(dest))
                    {
                        IMessage msg = consumer.Receive(new TimeSpan(0, 0, 1));
                        if (msg is ITextMessage)
                        {
                            ITextMessage txtMsg = msg as ITextMessage;
                            string body = txtMsg.Text;
                            Console.WriteLine("Received message: " + body);
                            this.Invoke((MethodInvoker)delegate
                            {
                                listView1.Items.Add(new ListViewItem(body));//invoke runs it on application thread.
                            });
                            Messages.Add(body);
                            return true;
                        }
                        else
                        {
                            Console.WriteLine("Unexpected message type: " + msg.GetType().Name);
                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
            return false;
        }
        public void ThreadProc()
        {
            while(true)
                if (((CheckBox)Mainform.Controls.Find("checkBox1", true)[0]).Checked)
                {
                    ReadNextMessage();
                }
        }
    }
}
